﻿/***************************************************************************

Copyright (c) Microsoft Corporation 2014.

This code is licensed using the Microsoft Public License (Ms-PL).  The text of the license
can be found here:

http://www.microsoft.com/resources/sharedsource/licensingbasics/publiclicense.mspx

***************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;

class ListItemRetriever01
{
    private class XmlStackItem
    {
        public XElement Element;
        public int[] LevelNumbers;
    }

    /*
     * This example loads each document into a byte array, then into a memory stream,
     * so that the document can be opened for writing without modifying the source document.
     */

    static void Main(string[] args)
    {
        var thisDir = new DirectoryInfo(".");
        foreach (var xmlFile in thisDir.GetFiles("*.xml"))
            xmlFile.Delete();
        using (WordprocessingDocument wDoc =
            WordprocessingDocument.Open("../../NumberedListTest.docx", false))
        {
            int abstractNumId = 0;
            XElement xml = ConvertDocToXml(wDoc, abstractNumId);
            Console.WriteLine(xml);
            xml.Save("Out.xml");
        }
        Console.WriteLine("Press Enter");
        Console.ReadKey();
    }

    private static XElement ConvertDocToXml(WordprocessingDocument wDoc, int abstractNumId)
    {
        XDocument xd = wDoc.MainDocumentPart.GetXDocument();

        // First, call RetrieveListItem so that all paragraphs are initialized with ListItemInfo
        var firstParagraph = xd.Descendants(W.p).FirstOrDefault();
        var listItem = ListItemRetriever.RetrieveListItem(wDoc, firstParagraph);

        XElement xml = new XElement("Root");
        var current = new Stack<XmlStackItem>();
        current.Push(
            new XmlStackItem()
            {
                Element = xml,
                LevelNumbers = new int[] { },
            });
        foreach (var paragraph in xd.Descendants(W.p))
        {
            // The following does not take into account documents that have tracked revisions.
            // As necessary, call RevisionAccepter.AcceptRevisions before converting to XML.
            var text = paragraph.Descendants(W.t).Select(t => (string)t).StringConcatenate();
            ListItemRetriever.ListItemInfo lii = 
                paragraph.Annotation<ListItemRetriever.ListItemInfo>();
            if (lii.IsListItem && lii.AbstractNumId == abstractNumId)
            {
                ListItemRetriever.LevelNumbers levelNums = 
                    paragraph.Annotation<ListItemRetriever.LevelNumbers>();
                if (levelNums.LevelNumbersArray.Length == current.Peek().LevelNumbers.Length)
                {
                    current.Pop();
                    var levelNumsForThisIndent = levelNums.LevelNumbersArray;
                    string levelText = levelNums
                        .LevelNumbersArray
                        .Select(l => l.ToString() + ".")
                        .StringConcatenate()
                        .TrimEnd('.');
                    var newCurrentElement = new XElement("Indent",
                        new XAttribute("Level", levelText));
                    current.Peek().Element.Add(newCurrentElement);
                    current.Push(
                        new XmlStackItem()
                        {
                            Element = newCurrentElement,
                            LevelNumbers = levelNumsForThisIndent,
                        });
                    current.Peek().Element.Add(new XElement("Heading", text));
                }
                else if (levelNums.LevelNumbersArray.Length > current.Peek().LevelNumbers.Length)
                {
                    for (int i = current.Peek().LevelNumbers.Length; 
                        i < levelNums.LevelNumbersArray.Length; 
                        i++)
                    {
                        var levelNumsForThisIndent = levelNums
                            .LevelNumbersArray
                            .Take(i + 1)
                            .ToArray();
                        string levelText = levelNums
                            .LevelNumbersArray
                            .Select(l => l.ToString() + ".")
                            .StringConcatenate()
                            .TrimEnd('.');
                        var newCurrentElement = new XElement("Indent",
                            new XAttribute("Level", levelText));
                        current.Peek().Element.Add(newCurrentElement);
                        current.Push(
                            new XmlStackItem()
                            {
                                Element = newCurrentElement,
                                LevelNumbers = levelNumsForThisIndent,
                            });
                        current.Peek().Element.Add(new XElement("Heading", text));
                    }
                }
                else if (levelNums.LevelNumbersArray.Length < current.Peek().LevelNumbers.Length)
                {
                    for (int i = current.Peek().LevelNumbers.Length;
                        i > levelNums.LevelNumbersArray.Length; 
                        i--)
                        current.Pop();
                    current.Pop();
                    var levelNumsForThisIndent = levelNums.LevelNumbersArray;
                    string levelText = levelNums
                        .LevelNumbersArray
                        .Select(l => l.ToString() + ".")
                        .StringConcatenate()
                        .TrimEnd('.');
                    var newCurrentElement = new XElement("Indent",
                        new XAttribute("Level", levelText));
                    current.Peek().Element.Add(newCurrentElement);
                    current.Push(
                        new XmlStackItem()
                        {
                            Element = newCurrentElement,
                            LevelNumbers = levelNumsForThisIndent,
                        });
                    current.Peek().Element.Add(new XElement("Heading", text));
                }
            }
            else
            {
                current.Peek().Element.Add(new XElement("Paragraph", text));
            }
        }
        return xml;
    }
}
