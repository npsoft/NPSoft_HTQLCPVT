﻿1. Links
- PowerTools for Open XML - Home :: http://powertools.codeplex.com/
- ASP NET Display DOCX - YouTube :: https://www.youtube.com/watch?v=Ygr6Sq5IRiA
- Writing Entity References using LINQ to XML - Eric White's Blog - Site Home - MSDN Blogs :: blogs.msdn.com/b/ericwhite/archive/2010/01/21/writing-entity-references-using-linq-to-xml.aspx
- Creating Documents by Using the Open XML Format SDK 2.0 CTP (Part 2 of 3) :: https://msdn.microsoft.com/en-us/library/dd452407(v=office.12).aspx
2. Example #01
- Libs
(1): OpenXmlPowerTools.dll
(2): DocumentFormat.OpenXml.dll
- Files
OpenXmlPowerToolsExamples\OrderReportController.cs(NPSoft_HTQLNHCS)
